# Website for a Simple Bolt IoT Wifi Module Application
This is a Website made for controlling the Bolt Wifi Module for a application of turning the GPIO Pin 1 of the Module high and low.
Can be used for simple Home Automation Application such as turning a LED On and Off.

